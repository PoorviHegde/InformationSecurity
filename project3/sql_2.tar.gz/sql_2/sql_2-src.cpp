#include <stdlib.h>
#include <iostream>
#include <openssl/md5.h>
#include <string>

// Compile using
// g++ -std=c++1z -o main sql_2-src.cpp -I/usr/local/opt/openssl/include -L/usr/local/opt/openssl/lib -lssl -lcrypto

using namespace std;

int main() {
	bool md5Found = false;
	int valBeingChanged = 0;

	while (!md5Found) {
		unsigned char digest[MD5_DIGEST_LENGTH];
		std::string temp;

		// generate random string
		for(unsigned int i = 0; i < 5; ++i)
		{
		    temp += char(rand() % (126 - 33 + 1) + 33);
		}
		const char* str = temp.c_str();

		MD5_CTX c;
		MD5_Init(&c);
		MD5_Update(&c, str, strlen(str));
		MD5_Final(digest, &c);

		// get md5 digest
		char md5CString[33];
		for(int i = 0; i < 16; i++)
			sprintf(&md5CString[i*2], "%02x", (unsigned int)digest[i]);

		string after = md5CString; 

		// check if the first 3 chars are '='
		if (after[0] == '2' && after[1] == '7' && after[2] == '3' && after[3] == 'd' && after[4] == '2' 
			&& after[5] == '7') {
			cout << "Password was : " << temp << endl;
			md5Found = true;
		}

	}

	return 0;	
}
